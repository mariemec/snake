#pragma once
#define WIDTH 500
#define HEIGHT 500
#define DOTSIZE (HEIGHT/(2*10))
